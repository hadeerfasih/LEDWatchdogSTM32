/*
 * LEDM.c
 *
 *  Created on: Jun 21, 2024
 *      Author: TEAM23
 *      Hadeer shrif
 *      Mariam hatem
 *      Marwan osama
 */

#include "LEDM.h"
#include "GPIO.h"
#include "WDGM.h"
#include <util/delay.h>

static unsigned char LEDState = 0;

void LEDM_Init(void)
{
    GPIO_Init();
    LEDState = 0;
}

void LEDM_Manage(void)
{
	// Turn on the LED for LEDM_Manage
	GPIO_Write(LED_LEDM, 1);

	static unsigned int counter = 0;
    if (counter >= 50) // 50 * 10ms = 500ms
    {
        LEDState = !LEDState;
        GPIO_Write(LED_PIN, LEDState);
        counter = 0;
    }
    else
    {
        counter++;
    }
    //_delay_ms(5);
	// Turn off the LED for LEDM_Manage
	GPIO_Write(LED_LEDM, 0);

    WDGM_AlivenessIndication();

}
