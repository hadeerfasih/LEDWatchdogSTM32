/*
 * GPIO.h
 *
 *  Created on: Jun 21, 2024
 *      Author: pc
 */

#ifndef GPIO_GPIO_H_
#define GPIO_GPIO_H_
#include <avr/io.h>
#define LED_PIN PB0 // Define LED_PIN here
#define LED_LEDM PB1   // LED for LEDM_Manage
#define LED_WDGM PB2   // LED for WDGM_MainFunction
#define LED_WDGDrv PB3 // LED for WDGDrv refreshment

//#define TEST_PIN_LED_BLINK PORTB0
//#define TEST_PIN_LEDM_MANAGE PORTB1
//#define TEST_PIN_WDGM_MAIN PORTB2
//#define TEST_PIN_WDG_REFRESH PORTB3

void GPIO_Init(void);
void GPIO_Write(unsigned char PinId, unsigned char PinData);

#endif /* GPIO_GPIO_H_ */
