
/*
 * main.c
 *
 *  Created on: Jun 21, 2024
 *      Author: TEAM23
 *      Hadeer shrif
 *      Mariam hatem
 *      Marwan osama
 */


#include "LEDM.h"
#include "WDGDRV.h"
#include "WDGM.h"
#include "GPIO.h"
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <avr/wdt.h>

// External declaration of variables
extern volatile uint8_t wdgmMainFunctionCalled; // Track the main function call

volatile unsigned char wdgmCounter = 0;


ISR(TIMER1_COMPA_vect)
{

//	status =!status;
//	 Set PB1 as output for debug LED
//	DDRB |= (1 << PB4);

//	 Toggle a debug LED to verify ISR timing
//	PINB |= (1 << PB4); // Toggle PB1 (assuming PB1 is connected to the LED)
//	GPIO_Write(LED_WDGDrv, status);

	 // Turn on debug LED
	uint8_t intervalCounter = 0;
//	static uint8_t watchdogCounter = 0;

    // Increment counter for 100ms interval (2 * 50ms)
    intervalCounter++;
//    watchdogCounter++;
    // Toggle a debug LED to verify ISR timing
//    GPIO_Write(LED_WDGDrv, 1);

    if (intervalCounter >= 1&&wdgmMainFunctionCalled){

         	WDGDrv_IsrNotification();


      }






}

void Timer1_Init(void)
{
	// Configure Timer1 for 50ms intervals
	TCCR1A=0;
	TCCR1B |= (1 << WGM12) | (1 << CS12); // CTC mode, prescaler 256
    TCNT1 = 0;                            // Initialize counter
    OCR1A = 195;                         // Set compare value for 50ms interval
    TIMSK1 |= (1 << OCIE1A);              // Enable CTC interrupt for Timer1

}

int main(void)
{

	// Initialize modules

    GPIO_Init();

    // nawar led deh f scenario negative
    //GPIO_Write(LED_WDGDrv, 1);
//	_delay_ms(50);


	LEDM_Init();
	Timer1_Init();
    WDGDrv_Init();
    WDGM_Init();

    sei(); // Enable global interrupts
    while (1)
    {

        LEDM_Manage(); // Call LED management function every 10ms (called by super loop)

        if (wdgmCounter >= 2) // 2 * 10ms = 20ms
        {

            WDGM_MainFunction(); // Call WDGM main function every 20ms
            wdgmCounter = 0;
        }


        wdgmCounter++;

        _delay_ms(10); // Simulate 10ms periodic call in super loop
    }
}
