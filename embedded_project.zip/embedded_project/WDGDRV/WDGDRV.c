/*
 * WDGDRV.c
 *
 *  Created on: Jun 21, 2024
 *      Author: TEAM23
 *      Hadeer shrif
 *      Mariam hatem
 *      Marwan osama
 */

//#include "WDGDRV.h"
//#include <avr/io.h>
//#include <avr/wdt.h>
//#include <avr/interrupt.h>
//#include "WDGM.h"
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/wdt.h>
#include "WDGDRV.h"
#include "GPIO.h"
#include "LEDM.h"
#include "WDGM.h"
#include <util/delay.h>

volatile uint8_t watchdogFlag = 0;
volatile unsigned char state = 1;
volatile unsigned char iter = 0;

void WDGDrv_Init(void)
{
    cli(); // Disable global interrupts

    // Clear the watchdog reset flag
    MCUSR &= ~(1 << WDRF);

    // Enable Watchdog Change Enable and Watchdog System Reset Enable
    WDTCSR |= (1 << WDCE) | (1 << WDE);

    // Set watchdog timeout to 64ms (
    WDTCSR = (1 << WDP1) | (1 << WDIE)  | (1 << WDE);
//    WDTCSR = (1 << WDP1) |(1 << WDIE) ;

    sei(); // Enable global interrupts
}

void WDGDrv_IsrNotification(void)
{
	iter++;
// Turn on the LED for WDGDrv refreshment
	// Turn on the LED for WDGDrv refreshment
	//GPIO_Write(LED_WDGDrv, 1);
    state=1;
    if(iter>=2){

    	iter=0;
		if(WDGM_PovideSuppervisionStatus()==NOK){
			GPIO_Write(LED_WDGDrv, 1);
			state=0;
		}
    }

	// Reset the watchdog timer
    if(state==1){

    	wdt_reset();
    	watchdogFlag = 1;
    }
    else{
    	//GPIO_Write(LED_WDGDrv, 0);
    }


    // Set the watchdog flag



//    _delay_ms(50);
    // Turn off the LED for WDGDrv refreshment
	//GPIO_Write(LED_WDGDrv, 0);

}

ISR(WDT_vect)
{
    // Clear the watchdog flag
    watchdogFlag = 0;
}
