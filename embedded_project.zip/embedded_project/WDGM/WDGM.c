/*
 * WDGM.c
 *
 *  Created on: Jun 21, 2024
 *      Author: TEAM23
 *      Hadeer shrif
 *      Mariam hatem
 *      Marwan osama
 */

#include "WDGM.h"
#include "GPIO.h"
#include <avr/io.h>
#include <util/delay.h>

static unsigned int ledmCallCount = 0;
static WDGM_StatusType WDGM_StatusVariable = NOK;
volatile uint8_t wdgmMainFunctionCalled = 0; // Initialize the variable
volatile unsigned char wdgmCallCounter = 0;

void WDGM_Init(void)
{
    // Initialize WDGM_Internal variables
    ledmCallCount = 0;
    WDGM_StatusVariable = NOK;
}

void WDGM_MainFunction(void)
{
    wdgmCallCounter++; // Increment the call counter
    wdgmMainFunctionCalled=1;

    if (wdgmCallCounter >= 5) // Check every 100ms (5 * 20ms)
    {
        wdgmCallCounter = 0; // Reset the counter

        // Turn on the LED for WDGM_MainFunction
        GPIO_Write(LED_WDGM, 1);

        // Check the number of calls of LEDM_Manage within a 100ms period
        if (ledmCallCount >= 8 && ledmCallCount <= 12)
        {

            // LEDM_Manage called within the acceptable range
            // Update the WDGM status to OK
            WDGM_StatusVariable = OK;
        }
        else
        {
            // LEDM_Manage not called within the acceptable range
            // Update the WDGM status to NOK
            WDGM_StatusVariable = NOK;
        }
        ledmCallCount = 0; // Reset the call count for the next period
    }
}

WDGM_StatusType WDGM_PovideSuppervisionStatus(void)
{
    // Provide the status of the LEDM entity to WDGDrv
    // Return the current WDGM status (OK or NOK)
    return WDGM_StatusVariable;
}

void WDGM_AlivenessIndication(void)
{
    // This function will be called from LEDM_Manage to detect its call at the correct timing
    // Increment the call count each time it is called
    ledmCallCount++;
}
