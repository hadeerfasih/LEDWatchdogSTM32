/*
 * WDGDRV.h
 *
 *  Created on: Jun 21, 2024
 *      Author: pc
 */

#ifndef WDGDRV_WDGDRV_H_
#define WDGDRV_WDGDRV_H_

void WDGDrv_Init(void);
void WDGDrv_IsrNotification(void);

#endif /* WDGDRV_WDGDRV_H_ */
