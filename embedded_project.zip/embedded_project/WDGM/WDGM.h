/*
 * WDGM.h
 *
 *  Created on: Jun 21, 2024
 *      Author: pc
 */

#ifndef WDGM_WDGM_H_
#define WDGM_WDGM_H_

typedef enum {OK = 0, NOK = 1}WDGM_StatusType;
void WDGM_Init(void);
void WDGM_MainFunction(void);
WDGM_StatusType WDGM_PovideSuppervisionStatus(void);
void  WDGM_AlivenessIndication(void);

#endif /* WDGM_WDGM_H_ */
