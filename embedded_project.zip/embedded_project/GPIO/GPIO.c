/*
 * GPIO.c
 *
 *  Created on: Jun 21, 2024
 *      Author: TEAM23
 *      Hadeer shrif
 *      Mariam hatem
 *      Marwan osama
 */


#include "GPIO.h"
#include <avr/io.h>

void GPIO_Init(void)
{
    // Set LED_PIN as output
    DDRB |= (1 << LED_PIN);
    // Set LED_LEDM, LED_WDGM, LED_WDGDrv as outputs
    DDRB |= (1 << LED_LEDM);
    DDRB |= (1 << LED_WDGM);
    DDRB |= (1 << LED_WDGDrv);

//    DDRB |= (1 << PB0);  // Set PB0 as output
//    GPIO_Write(LED_PIN, 0);  // Ensure LED is initially off


}

void GPIO_Write(unsigned char PinId, unsigned char PinData)
{
    if (PinData)
    {
        PORTB |= (1 << PinId); // Set pin high
    }
    else
    {
        PORTB &= ~(1 << PinId); // Set pin low
    }
}
