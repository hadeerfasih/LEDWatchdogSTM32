/*
 * LEDM.h
 *
 *  Created on: Jun 21, 2024
 *      Author: pc
 */

#ifndef LEDM_LEDM_H_
#define LEDM_LEDM_H_

void LEDM_Init(void);
void LEDM_Manage(void);

#endif /* LEDM_LEDM_H_ */
